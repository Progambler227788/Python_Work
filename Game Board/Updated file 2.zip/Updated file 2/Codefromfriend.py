import sys
import stdio

sinks = []
blocked = []
dark = []
light = []


def print_game_board(rows, cols, board):
    # Check For Any Moves In File
    try:
        while True:
            line = stdio.readString()
            user_moves = line.split(' ')
            check_move(user_moves[0], user_moves[1], user_moves[2], board)
    except:
        pass
    # Print the first row
    stdio.write("  ")
    for i in range(cols):
        stdio.write(f" {i} ")

    stdio.write("\n")
    # Print the top border
    stdio.write("  " + "+--" * cols + "+ \n")

    # Print each row
    for i in range(rows - 1, -1, -1):
        # Print the left border
        stdio.write(f"{i} |")

        # Print each cell
        for j in range(cols):
            if board[i][j] == ' ':
                stdio.write("  |")
            else:
                if isinstance(board[i][j], str):
                    stdio.write(f" {board[i][j]}|")
                elif isinstance(board[i][j], int):
                    if len(str(board[i][j])) < 2:
                        stdio.write(f" {board[i][j]}|")
                    else:
                        stdio.write(f"{board[i][j]}|")

        # Print the right border
        stdio.write("\n")
        stdio.write("  " + "+--" * cols + "+ \n")


def process_input(n, m, mode):
    board = [[' ' for j in range(m)] for i in range(n)]
    inputs = [n, m, mode]
    # Input Validation
    if (n < 8 or n > 10) or (n < 8 or n > 10):
        stdio.write("ERROR : Illegal Arguments")
    else:
        if n == "" or m == "" or mode == "":
            stdio.write("ERROR : ")
        else:
            try:
                while True:
                    line = stdio.readString()
                    user_inputs = line.split(' ')
                    if len(user_inputs) != 4:
                        check_piece(user_inputs[0], user_inputs[1], user_inputs[2], 0, n, m)
                    else:
                        check_piece(user_inputs[0], user_inputs[1], user_inputs[2], user_inputs[3], n, m)
            except:
                pass
            draw_game(board, n, m)


def check_piece(c, in1, in2, in3, n, m):
    # CHECK IF OBJECT TYPE IS LEGAL
    if c not in ('s', 'l', 'd', 'x'):
        stdio.write(f"ERROR: Invalid object type {c} \n")
        exit()
    # CHECK IF COORDINATES OF MOVE ARE INTEGERS AND ALSO WITHIN RANGE OF THE BOARD
    try:
        in2 = int(in2)
        in3 = int(in3)
        # CHECK IF COORDINATES ARE WITHIN RANGE
        if (in2 in range(n)) and (in3 in range(m)):
            pass
        else:
            stdio.write(f"ERROR: Field {in2} {in3} not on board. \n")
            exit()
    except ValueError:
        stdio.write(f"ERROR: Field {in2} {in3} not on board. \n")
        exit()
    # CONVERT THE DIMENSIONS OF THE PIECE INTO AN INTEGER AND CHECK IF PIECE TYPES ARE LEGAL
    try:
        # ONLY APPLY TO FIELDS THAT ARE NOT BLOCKED FIELDS
        if c != 'x':
            if c != 'd' and c != 'l':
                in1 = int(in1)
                if in1 not in (1, 2):
                    stdio.write(f"ERROR: Invalid piece type {in1} \n")
                    exit()
            else:
                if in1 not in ("a", "b", "c", "d"):
                    stdio.write(f"ERROR: Invalid piece type {in1} \n")
                    exit()
    except ValueError:
        stdio.write(f"ERROR: Invalid piece type {in1} \n")
        exit()
    # INITIALIZE GAME BOARD
    board = [[' ' for j in range(m)] for i in range(n)]
    # COLLECT OBJECTS INTO RELEVANT LISTS
    if c.lower() == 's':
        # CHECK IF SINK FIELD WILL BE FULLY WITHIN THE OUTER THREE ROWS OR COLUMNS
        if in2 in range(0, 3) or in2 in range(n - 3, n):
            if in3 in range(0, 3) or in3 in range(m - 3, m):
                pass
            else:
                stdio.write(f"ERROR: Sink in the wrong position.\n")
                exit()
        else:
            stdio.write(f"ERROR: Sink in the wrong position.\n")
            exit()
        # IF SINK PASSES CONSTRAINTS, APPEND TO LIST
        sinks.append([c, in1, in2, in3])
    elif c.lower() == 'x':
        # CHECK IF FIELD WILL BE FULLY WITHIN THE OUTER THREE ROWS OR COLUMNS
        in1 = int(in1)
        blocked.append([c, in1, in2])
    elif c.lower() == 'd':
        if in2 in range(0, 3) or in2 in range(n - 3, n):
            stdio.write(f"ERROR: Piece in the wrong position.\n")
            exit()
        else:
            if in3 in range(0, 3) or in3 in range(m - 3, m):
                stdio.write(f"ERROR: Piece in the wrong position.\n")
                exit()
            else:
                pass
        dark.append([c, in1, in2, in3])
    else:
        if in2 in range(0, 3) or in2 in range(n - 3, n):
            stdio.write(f"ERROR: Piece in the wrong row position.{in2}\n")
            exit()
        else:
            if in3 in range(0, 3) or in3 in range(m - 3, m):
                stdio.write(f"ERROR: Piece in the wrong column position. {in3} \n")
                exit()
            else:
                pass
        light.append([c, in1, in2, in3])


def draw_game(board, n, m):
    for s in sinks:
        if s[1] == 2:
            board[s[2] + 1][s[3]] = s[0]
            board[s[2]][s[3] + 1] = s[0]
            board[s[2] + 1][s[3] + 1] = s[0]
        board[s[2]][s[3]] = s[0]
    for x in blocked:
        board[x[1]][x[2]] = x[0]
    for d in dark:
        if d[1] == "a":
            pass
        elif d[1] == "b":
            pass
        elif d[1] == "c":
            pass
        else:
            board[d[2] + 1][d[3]] = (d[2] * 10 + d[3])
            board[d[2]][d[3] + 1] = (d[2] * 10 + d[3])
            board[d[2] + 1][d[3] + 1] = (d[2] * 10 + d[3])
        board[d[2]][d[3]] = d[1].upper()
    for lt in light:
        if lt[1] == "a":
            pass
        elif lt[1] == "b":
            pass
        elif lt[1] == "c":
            pass
        else:
            board[lt[2] + 1][lt[3]] = (lt[2] * 10 + lt[3])
            board[lt[2]][lt[3] + 1] = (lt[2] * 10 + lt[3])
            board[lt[2] + 1][lt[3] + 1] = (lt[2] * 10 + lt[3])
        board[lt[2]][lt[3]] = lt[1]
    print_game_board(n, m, board)


def check_move(n, m, move, board):
    n = int(n)
    m = int(m)
    # CHECK IF MOVE IS WITHIN THE RANGE OF THE GAME BOARD
    if board[n][m] == '':
        stdio.write(f'ERROR: No piece on field {n} {m}')
        exit()
    else:
        # Check Specified Move
        if move.strip() == "l":
            # Check If The Location Is Empty
            if str(board[n][m - 1]).strip() == "":
                make_move(n, m, move, board)
            else:
                stdio.write(f"ERROR: Field {n} {m} not free")
                exit()
        elif move.strip() == "r":
            # Check If The Location Is Empty
            if str(board[n][m + 1]).strip() == "":
                make_move(n, m, move, board)
            else:
                stdio.write(f"ERROR: Field {n} {m} not free")
                exit()
        elif move.strip() == "u":
            # Check If The Location Is Empty
            if str(board[n - 1][m]).strip() == "":
                make_move(n, m, move, board)
            else:
                stdio.write(f"ERROR: Field {n} {m} not free")
                exit()
        elif move.strip() == "d":
            # Check If The Location Is Empty
            if str(board[n + 1][m]).strip() == "":
                make_move(n, m, move, board)
            else:
                stdio.write(f"ERROR: Field {n} {m} not free")
                exit()


def make_move(n, m, move, board):
    # CHECK IF DIRECTION OF MOVE IS LEGAL
    if move not in ("u", "r", "d", "l"):
        if move.strip() == "l":
            board[n][m - 1] = board[n][m]
            board[n][m] = ''
        elif move.strip() == "r":
            board[n][m + 1] = board[n][m]
            board[n][m] = ''
        elif move.strip() == "u":
            board[n - 1][m] = board[n][m]
            board[n][m] = ''
        elif move.strip() == "d":
            board[n + 1][m] = board[n][m]
            board[n][m] = ''
    else:
        stdio.write(f"ERROR: Invalid direction {move}")
        exit()
    print_game_board(10, 10, board)


def main():
    args = len(sys.argv)
    # CHECK VALIDITY OF ARGUMENTS
    if args > 4:
        stdio.write("ERROR: Too many arguments \n")
        exit()
    elif args < 4:
        stdio.write("ERROR: Too few arguments \n")
        exit()
    elif args == 4:
        try:
            rows = int(sys.argv[1])
            cols = int(sys.argv[2])
            game_mode = int(sys.argv[3])
        except:
            stdio.write("ERROR: Illegal argument \n")
            exit()
        if isinstance(rows, str) or isinstance(cols, str) or isinstance(game_mode, str):
            stdio.write("ERROR: Illegal argument \n")
            exit()
        else:
            if rows not in range(8, 11) or cols not in range(8, 11) or game_mode not in range(0, 2):
                stdio.write("ERROR: Illegal argument \n")
                exit()
            else:
                pass
        process_input(rows, cols, game_mode)


if __name__ == '__main__':
    main()

# Deal With Errors

