# Question 4
# Import Random Library
import random

def generate_random_list():
    """
    This function generates a list with 10 random integers between 1 and 50.
    """
    listGenerated = []
    # _ will server as loop for iterating 10 time to have 10 elements picked from 1 to 50 placed in list
    for _ in range(10,0,-1):
        listGenerated.append(random.randint(1, 50))
        
    return listGenerated

def replace_multiples_of_5(original):
    """
    Replaces elements in the list that are multiples of 5 with their squares.
    """
    listSquares = []
    for element in original:
        # It will check if element is divisble by 5 using mod operator
        if element % 5 == 0:
            listSquares.append(element ** 2)
        # If element is not multiple of 5, then add it as same.
        else:
            listSquares.append(element)          
    # Return new list  
    return listSquares

# Generate a random list
random_list = generate_random_list()
# Prints Original List
print("Original list:", random_list)

# Replace multiples of 5 with their squares
modified_list = replace_multiples_of_5(random_list)
# Print Modified List
print("Modified list:", modified_list)